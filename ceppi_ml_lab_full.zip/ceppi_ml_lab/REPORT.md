# Replicating Sánchez-Arévalo et al. (2026) with Data-Driven ML Models

**Paper:** *Continuous regeneration of the draw solution in textile wastewater treatment using a
combination of simultaneous forward osmosis and reverse osmosis*, Chem. Eng. Process.: Process
Intensification 221 (2026) 110689.

This lab uses the three raw Excel datasets released alongside the paper to train machine-learning
models that reproduce its four main experimental results, rather than re-deriving the paper's
physics equations from scratch. All models are trained directly on logged instrument data
(flow meters, conductivity/temperature probes, balances) or on the sample-analysis lab results —
not on numbers copied from the paper's figures/tables, which are used only for validation.

## 1. Data used

| File | Sheets used | What it contains |
|---|---|---|
| `CEPPI_2025_dataset_A.xlsx` | FO permeate flux, Sample analysis | Short-term run (real end-of-pipe wastewater, ~2 h): 11 flux readings + lab analyses (pH, conductivity, TDS, TOC, TN) of feed-in/feed-out/draw-out at 6 recovery levels (25–90%) |
| `CEPPI_2025_dataset_B.xlsx` | Raw replicate 1, Raw data replicate 2, Calculations FO | Longer-term run (6 h, previously-concentrated feed), two replicates. Replicate 1: ~2700 rows of 1 Hz-ish sensor logs (flows, pressures, conductivities, temperatures) plus a derived flux column. Replicate 2: same sensor set but missing the feed-outlet-flow channel needed for the paper's own flux formula (confirmed broken `#REF!` in the source workbook) |
| `CEPPI_2025_water_tests.xlsx` | FO - water as feed, RO - NaCl 0.5 M | Membrane quality-control tests: FO with DI water/0.5 M NaCl draw (baseline flux), RO with 0.5 M NaCl feed at 30/40/50 bar (rejection & flux vs pressure) |

## 2. Models built

### Model 1a — FO permeate flux, longer-term run (replicate 1) — replicates **Fig. 6A**
- **Type:** RandomForestRegressor (400 trees, depth 8)
- **Features:** time, FO feed/draw conductivity, FO feed/draw temperature, RO TMP, FO TMP (all logged, n=709 rows after cleaning)
- **Target:** Jw = (feed-in flow − feed-out flow) / membrane area, i.e. the same formula the paper's authors use internally
- **Evaluation:** chronological 75/25 split (train on the first ~4.5 h, test on the last ~1.5 h) *and* 5-fold random CV
- **Result:** 5-fold CV R² = **0.77** (mean of folds 0.67–0.85). The chronological holdout is *negative* (R² ≈ −0.05) — the model cannot extrapolate to the final ~90 min, where flux dips as the paper describes a cleaning/rinsing event. This is an honest and informative failure: it shows the flux decline near the end is driven by an operational event (membrane cleaning), not by the smooth sensor trends the model was trained on.
- **Paper comparison:** reported flux range 3.9–4.1 L/h·m²; our cleaned data mean/SD is consistent with that band, and the model's predicted curve reproduces the same oscillating-but-stable shape.

### Model 1b — FO permeate flux, short-term run — replicates **Fig. 3A**
- **Type:** GradientBoostingRegressor (small, shallow — 150 trees, depth 2) to avoid overfitting on n=11
- **Features:** time, water recovery %, feed conductivity — the latter two interpolated from the Sample-analysis sheet using the recovery% timestamps annotated in the paper's own Fig. 3A
- **Evaluation:** Leave-one-out CV, **R² = 0.42**, RMSE = 1.13 L/h·m²
- **Result:** the model correctly reproduces the flux decline from ~8 down to ~3.7 L/h·m² as recovery rises, and the sharp recovery jump back up to ~6 L/h·m² at the cartridge-filter replacement (~107 min / 85–90% recovery) — the signature feature of Fig. 3A.

### Model 2 — RO rejection & permeate flow vs pressure — replicates **Fig. 2B**
- **Type:** degree-2 polynomial regression (rejection) + linear regression (permeate flow), fit on the 3 calibration pressures (30/40/50 bar) with leave-one-out CV
- **Result:** rejection LOOCV R² is unstable (as expected with only 3 points — each fold fits a line through 2 points), but the fitted curve at 50 bar predicts **99.2% rejection**, matching the paper's reported value almost exactly. Permeate-flow LOOCV R² = **0.997** (flow vs TMP is very linear, as the paper also notes).

### Model 3 — TOC / TDS / conductivity vs water recovery — replicates **Table 4 & Table 5**
- **Type:** linear regression, using a physically-motivated feature: concentration factor CF = 1/(1 − recovery/100) (the same mass-balance logic the paper uses for its recovery equation, Eq. 2)
- **Result:** Feed-in and feed-out streams show strong linear-in-CF behaviour (LOOCV R² = 0.76–0.98). Draw-out stream is *not* well fit by this model (R² < 0, i.e. worse than predicting the mean) — which is the correct physical finding: the draw solution stays roughly constant because RO continuously regenerates it, exactly the paper's central claim.
- **Derived rejection:** computing TOC rejection = 1 − (draw-out TOC / feed-in TOC) from the fitted/measured values gives 98.2% (25%), 98.9% (50%), 98.9% (75%), 99.3% (80%), 99.6% (85%) — within ~0.4–1.1 percentage points of the paper's Table 4 values (99.3%, 99.7%, 99.1%, —, —, 99.9%).

## 3. Key limitations / honesty notes

- **Replicate 2 flux could not be reconstructed reliably.** The paper's own spreadsheet formula for it is broken (`#REF!`), and the required feed-outlet-flow sensor channel isn't logged in that replicate. A weight/volume-based reconstruction was attempted but gave physically inconsistent values (orders of magnitude off), so it was **dropped** rather than reported as if it worked.
- **COD is not present in the dataset** (only TOC/TDS/conductivity are logged per-sample), so Model 3 validates against the paper's TOC rejection numbers, not COD.
- Small sample sizes (n=3 for RO calibration, n=6 recovery levels, n=11 short-term flux points) mean LOOCV R² for some sub-models is noisy — this is reported transparently rather than smoothed over with a model complex enough to look good on training data alone.

## 4. Files delivered
- `data/*.csv` — cleaned, feature-engineered datasets extracted from the three workbooks
- `models/*.txt` — quantitative metrics for each model
- `models/fo_flux_longterm_rf.joblib` — trained RandomForest model
- `plots/*.png` — four figures directly comparable to the paper's Fig. 2B, 3A, 6A and Table 4/5
- `train_*.py` — the four training scripts (fully reproducible, re-run with `python3 train_X.py`)
